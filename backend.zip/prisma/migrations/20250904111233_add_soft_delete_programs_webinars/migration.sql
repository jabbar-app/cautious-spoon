-- DropIndex
DROP INDEX "public"."idx_candidate_webinars_deleted_at";
