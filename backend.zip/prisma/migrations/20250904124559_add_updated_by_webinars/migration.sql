-- AlterTable
ALTER TABLE "public"."webinars" ADD COLUMN     "updated_by" VARCHAR(225);
