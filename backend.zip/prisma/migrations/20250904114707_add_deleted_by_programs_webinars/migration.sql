-- AlterTable
ALTER TABLE "public"."programs" ADD COLUMN     "updated_by" VARCHAR(225);
