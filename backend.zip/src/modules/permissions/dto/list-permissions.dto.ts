// src/modules/permissions/dto/list-permissions.dto.ts
import { ListQueryDto } from '../../../common/dto/list-query.dto';
export class ListPermissionsDto extends ListQueryDto {}