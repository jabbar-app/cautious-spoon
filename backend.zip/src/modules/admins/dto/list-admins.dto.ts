// src/modules/admins/dto/list-admins.dto.ts
// import { ListQueryDto } from '@/common/dto/list-query.dto';
import { ListQueryDto } from '../../../common/dto/list-query.dto';
export class ListAdminsDto extends ListQueryDto {}
