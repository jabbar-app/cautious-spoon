// src/modules/roles/dto/list-roles.dto.ts
import { ListQueryDto } from '../../../common/dto/list-query.dto';
export class ListRolesDto extends ListQueryDto {}
